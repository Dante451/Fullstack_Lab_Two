# COMP-4002 Lab 2 Starter

### Getting Started

```
  npm i

  npm run dev
```
