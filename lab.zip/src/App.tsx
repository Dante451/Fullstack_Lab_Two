import "./App.css";
import { Nav } from "./components/nav/Nav";
import { EmployeeList } from "./components/employee-list/EmployeeList";
import { Footer } from "./components/footer/footer";
import Header from "./components/header/Header";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Organization from "./components/organization/Organization";

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <Header />

      <Routes>
        <Route path="/employees" element={<EmployeeList />} />
        <Route path="/organization" element={<Organization />} />
        {/* default -> employees */}
        <Route path="/" element={<Navigate to="/employees" replace />} />
      </Routes>

      <Footer />
    </BrowserRouter>
  );
}

export default App;
